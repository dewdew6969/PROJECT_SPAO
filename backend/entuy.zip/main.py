from fastapi import FastAPI, Depends, HTTPException, status, UploadFile, File, Form, WebSocket, WebSocketDisconnect
from sqlalchemy.orm import Session
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from typing import List
from datetime import timedelta, datetime
import math
import os
import shutil
import smtplib
from email.mime.text import MIMEText
import random
import requests

import models, schemas, auth
from database import engine, get_db, SessionLocal
import asyncio

SMTP_SERVER = os.environ.get("SMTP_SERVER", "smtp.gmail.com")
SMTP_PORT = int(os.environ.get("SMTP_PORT", 465))
SMTP_USERNAME = os.environ.get("SMTP_USERNAME", "sparoofficial2026@gmail.com")
SMTP_PASSWORD = os.environ.get("SMTP_PASSWORD", "xbfxvxadsepbemqw")

def send_otp_email(to_email: str, otp_code: str):
    msg = MIMEText(f"Halo!\n\nKode OTP Anda untuk pendaftaran Sparo adalah: {otp_code}\n\nKode ini berlaku selama 15 menit.\n\nSalam,\nTim Sparo")
    msg['Subject'] = 'Kode OTP Pendaftaran Sparo'
    msg['From'] = SMTP_USERNAME
    msg['To'] = to_email

    try:
        if SMTP_PORT == 465:
            server = smtplib.SMTP_SSL(SMTP_SERVER, SMTP_PORT, timeout=10)
        else:
            server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT, timeout=10)
            server.starttls()
            
        server.login(SMTP_USERNAME, SMTP_PASSWORD)
        server.sendmail(SMTP_USERNAME, to_email, msg.as_string())
        server.quit()
        return True
    except Exception as e:
        print(f"Failed to send email: {e}")
        return False

app = FastAPI(title="Sparo API", description="API Backend untuk aplikasi Sparo menggunakan FastAPI")

# Konfigurasi CORS agar aplikasi React Native bisa mengakses API ini
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")

# --- FUNGSI ELO RATING STANDAR INTERNASIONAL ---
def calculate_elo(rating_a, rating_b, score_a):
    """
    Hitung ELO Rating baru berdasarkan rumus Arpad Elo.
    score_a = 1 (A menang), 0.5 (Seri), 0 (A kalah)
    """
    K = 32 # Konstanta k-factor standar turnamen publik
    expected_a = 1 / (1 + 10 ** ((rating_b - rating_a) / 400))
    expected_b = 1 - expected_a
    
    new_rating_a = round(rating_a + K * (score_a - expected_a))
    new_rating_b = round(rating_b + K * ((1 - score_a) - expected_b))
    
    return new_rating_a, new_rating_b

# --- FUNGSI HAVERSINE (HITUNG JARAK) ---
def calculate_distance(lat1, lon1, lat2, lon2):
    R = 6371.0 # Radius of the Earth in km
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat / 2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    distance = R * c
    return distance * 1000 # returns meters

# --- BACKGROUND TASK: GHOSTING MONITOR ---
async def ghosting_monitor_task():
    while True:
        try:
            db = SessionLocal()
            now = datetime.utcnow()
            
            # Cari pertandingan yang sudah lewat 10 menit dari match_end_date dan berstatus ACCEPTED
            matches = db.query(models.Challenge).filter(
                models.Challenge.status == "ACCEPTED",
                models.Challenge.match_end_date != None,
                models.Challenge.match_end_date <= now - timedelta(minutes=10)
            ).all()
            
            for match in matches:
                challenger = db.query(models.User).filter(models.User.id == match.challenger_id).first()
                opponent = db.query(models.User).filter(models.User.id == match.opponent_id).first()
                
                if not match.challenger_checked_in and not match.opponent_checked_in:
                    # Keduanya tidak datang (Sama-sama Ghosting)
                    match.status = "CANCELLED"
                    if challenger: challenger.trust_score = max(0, challenger.trust_score - 2)
                    if opponent: opponent.trust_score = max(0, opponent.trust_score - 2)
                    
                elif match.challenger_checked_in and not match.opponent_checked_in:
                    # Lawan Ghosting
                    match.status = "COMPLETED"
                    match.winner_id = match.challenger_id
                    if challenger and opponent:
                        # Challenger Menang (score_a = 1)
                        new_c_elo, new_o_elo = calculate_elo(challenger.elo, opponent.elo, 1)
                        challenger.elo = max(0, new_c_elo)
                        opponent.elo = max(0, new_o_elo)
                        opponent.trust_score = max(0, opponent.trust_score - 20)
                    
                elif not match.challenger_checked_in and match.opponent_checked_in:
                    # Penantang Ghosting
                    match.status = "COMPLETED"
                    match.winner_id = match.opponent_id
                    if challenger and opponent:
                        # Challenger Kalah / Lawan Menang (score_a = 0)
                        new_c_elo, new_o_elo = calculate_elo(challenger.elo, opponent.elo, 0)
                        challenger.elo = max(0, new_c_elo)
                        opponent.elo = max(0, new_o_elo)
                        challenger.trust_score = max(0, challenger.trust_score - 20)
                    
                # Jika keduanya check-in, biarkan (menunggu input skor di endpoint lain)
            
            if matches:
                db.commit()
                
        except Exception as e:
            print(f"Error di Ghosting Monitor: {e}")
        finally:
            db.close()
            
        # Tunggu 5 menit sebelum ngecek lagi
        await asyncio.sleep(300)

# Background task removed for WSGI compatibility. Use cPanel Cron with cron_job.py instead.

@app.get("/")
def read_root():
    return {"message": "Selamat datang di Sparo API Backend!"}

@app.get("/ping")
def ping():
    return {"status": "ok"}

@app.get("/setup-db")
def setup_db():
    models.Base.metadata.create_all(bind=engine)
    return {"message": "Database tables created successfully!"}

# --- ENDPOINT AUTENTIKASI ---
@app.post("/api/auth/send-otp")
def send_otp(data: schemas.OTPSend, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.email == data.email).first()
    if user:
        raise HTTPException(status_code=400, detail="Email sudah terdaftar")
        
    otp_code = str(random.randint(100000, 999999))
    expires_at = datetime.utcnow() + timedelta(minutes=15)
    
    db_otp = models.OTPCode(email=data.email, code=otp_code, expires_at=expires_at)
    db.add(db_otp)
    db.commit()
    
    success = send_otp_email(data.email, otp_code)
    return {"message": "OTP terkirim" if success else "Gagal mengirim email OTP, namun OTP telah di-generate", "success": success}

@app.post("/login")
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    # Cari berdasarkan username atau email
    user = db.query(models.User).filter(
        (models.User.username == form_data.username) | (models.User.email == form_data.username)
    ).first()
        
    if not user or not auth.verify_password(form_data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Email/Username atau password salah",
            headers={"WWW-Authenticate": "Bearer"},
        )
        
    access_token_expires = timedelta(minutes=auth.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = auth.create_access_token(
        data={"sub": str(user.id)}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer", "user": user}

# --- ENDPOINT USERS ---
@app.post("/users/", response_model=schemas.User)
def create_user(user: schemas.UserCreateWithOTP, db: Session = Depends(get_db)):
    db_otp = db.query(models.OTPCode).filter(
        models.OTPCode.email == user.email, 
        models.OTPCode.code == user.otp_code,
        models.OTPCode.expires_at >= datetime.utcnow()
    ).order_by(models.OTPCode.id.desc()).first()
    
    if not db_otp:
        raise HTTPException(status_code=400, detail="Kode OTP tidak valid atau sudah kadaluarsa")

    db_user = db.query(models.User).filter(models.User.email == user.email).first()
    if db_user:
        raise HTTPException(status_code=400, detail="Email sudah terdaftar")
        
    hashed_password = auth.get_password_hash(user.password)
    db_user = models.User(
        username=user.username,
        full_name=user.full_name,
        email=user.email,
        hashed_password=hashed_password,
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

@app.get("/users/{user_id}", response_model=schemas.User)
def read_user(user_id: int, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if user is None:
        raise HTTPException(status_code=404, detail="User tidak ditemukan")
    return user

@app.put("/users/{user_id}", response_model=schemas.User)
def update_user(user_id: int, user_update: schemas.UserUpdate, db: Session = Depends(get_db)):
    db_user = db.query(models.User).filter(models.User.id == user_id).first()
    if not db_user:
        raise HTTPException(status_code=404, detail="User tidak ditemukan")
    
    update_data = user_update.dict(exclude_unset=True)
    for key, value in update_data.items():
        setattr(db_user, key, value)
        
    db.commit()
    db.refresh(db_user)
    return db_user

@app.put("/users/{user_id}/status")
def update_user_status(user_id: int, is_online: bool, db: Session = Depends(get_db)):
    db_user = db.query(models.User).filter(models.User.id == user_id).first()
    if not db_user:
        raise HTTPException(status_code=404, detail="User tidak ditemukan")
    
    db_user.is_online = is_online
    db_user.last_active = datetime.utcnow()
    db.commit()
    return {"message": "Status updated", "is_online": is_online}

@app.get("/opponents/", response_model=List[schemas.User])
def get_opponents(
    skip: int = 0, 
    limit: int = 100, 
    lat: float = None, 
    lon: float = None, 
    max_distance: float = None, 
    db: Session = Depends(get_db)
):
    users = db.query(models.User).offset(skip).limit(limit).all()
    
    # Haversine Calculation & Filtering
    result = []
    for user in users:
        # Construct dictionary since we are returning dynamic distance
        user_dict = {c.name: getattr(user, c.name) for c in user.__table__.columns}
        
        if lat is not None and lon is not None and user.latitude and user.longitude:
            dist_meters = calculate_distance(lat, lon, user.latitude, user.longitude)
            dist_km = dist_meters / 1000.0
            user_dict['distance'] = round(dist_km, 2)
            
            # Filter if max_distance is specified (in km)
            if max_distance is not None and dist_km > max_distance:
                continue
        else:
            user_dict['distance'] = None
            
        result.append(user_dict)
        
    return result

# Endpoint Challenges
@app.post("/challenges/", response_model=schemas.Challenge)
def create_challenge(challenge: schemas.ChallengeCreate, challenger_id: int, db: Session = Depends(get_db)):
    db_challenge = models.Challenge(**challenge.dict(), challenger_id=challenger_id)
    db.add(db_challenge)
    db.commit()
    db.refresh(db_challenge)
    return db_challenge

@app.get("/challenges/{user_id}", response_model=List[schemas.Challenge])
def get_user_challenges(user_id: int, db: Session = Depends(get_db)):
    challenges = db.query(models.Challenge).filter(
        (models.Challenge.challenger_id == user_id) | (models.Challenge.opponent_id == user_id)
    ).all()
    return challenges

# --- ENDPOINT PELAPORAN & MODERASI ---
@app.post("/api/reports/", response_model=schemas.Report)
def create_report(report: schemas.ReportCreate, current_user_id: int, db: Session = Depends(get_db)):
    # 1. Simpan laporan ke tabel
    db_report = models.Report(
        reporter_id=current_user_id,
        reported_id=report.reported_id,
        category=report.category
    )
    db.add(db_report)
    
    # 2. Ambil data User B (Yang dilaporkan)
    reported_user = db.query(models.User).filter(models.User.id == report.reported_id).first()
    if not reported_user:
        raise HTTPException(status_code=404, detail="User not found")
        
    # 3. Penalti Trust Score (Kurangi 15 poin setiap laporan)
    reported_user.trust_score = max(0, reported_user.trust_score - 15)
    
    # 4. Sistem Deteksi Otomatis (Auto-Moderation)
    # Cek berapa banyak orang berbeda yang melaporkan user ini dalam 24 jam terakhir
    yesterday = datetime.utcnow() - timedelta(days=1)
    unique_reporters_count = db.query(models.Report.reporter_id).filter(
        models.Report.reported_id == report.reported_id,
        models.Report.created_at >= yesterday
    ).distinct().count()
    
    # Jika dilaporkan oleh 5 orang berbeda dalam 1 hari -> Auto Suspend
    if unique_reporters_count >= 5:
        reported_user.is_suspended = True
        
    db.commit()
    db.refresh(db_report)
    return db_report

# --- ENDPOINT RESPOND CHALLENGE ---
@app.post("/challenges/{challenge_id}/respond")
def respond_challenge(challenge_id: int, user_id: int, is_accepted: bool, db: Session = Depends(get_db)):
    challenge = db.query(models.Challenge).filter(models.Challenge.id == challenge_id).first()
    if not challenge:
        raise HTTPException(status_code=404, detail="Challenge not found")
        
    if challenge.opponent_id != user_id:
        raise HTTPException(status_code=403, detail="Hanya lawan yang diundang yang bisa merespon")
        
    if is_accepted:
        challenge.status = "ACCEPTED"
    else:
        challenge.status = "REJECTED"
        
    db.commit()
    db.refresh(challenge)
    return {"message": "Respon berhasil disimpan", "challenge": challenge}

# --- ENDPOINT MATCH VERIFICATION ---


@app.post("/challenges/{challenge_id}/checkin")
def checkin_match(challenge_id: int, user_id: int, lat: float, lon: float, db: Session = Depends(get_db)):
    challenge = db.query(models.Challenge).filter(models.Challenge.id == challenge_id).first()
    if not challenge:
        raise HTTPException(status_code=404, detail="Challenge not found")
        
    # Check distance (e.g., within 500 meters)
    if challenge.venue_lat and challenge.venue_lon:
        distance = calculate_distance(lat, lon, challenge.venue_lat, challenge.venue_lon)
        if distance > 500:
            raise HTTPException(status_code=400, detail=f"Terlalu jauh dari lokasi pertandingan. Jarak Anda: {distance:.2f} meter")
            
    if challenge.challenger_id == user_id:
        challenge.challenger_checked_in = True
    elif challenge.opponent_id == user_id:
        challenge.opponent_checked_in = True
    else:
        raise HTTPException(status_code=403, detail="Anda bukan peserta pertandingan ini")
        
    db.commit()
    db.refresh(challenge)
    return {"message": "Check-in berhasil", "challenge": challenge}

@app.post("/challenges/{challenge_id}/submit-score")
def submit_score(challenge_id: int, user_id: int, my_score: int, opponent_score: int, db: Session = Depends(get_db)):
    challenge = db.query(models.Challenge).filter(models.Challenge.id == challenge_id).first()
    if not challenge:
        raise HTTPException(status_code=404, detail="Challenge not found")
        
    if challenge.challenger_id == user_id:
        challenge.challenger_score = my_score
        challenge.opponent_score = opponent_score
    elif challenge.opponent_id == user_id:
        challenge.opponent_score = my_score
        challenge.challenger_score = opponent_score
    else:
        raise HTTPException(status_code=403, detail="Akses ditolak")
        
    db.commit()
    db.refresh(challenge)
    return {"message": "Skor berhasil disubmit, menunggu konfirmasi lawan", "challenge": challenge}

@app.post("/challenges/{challenge_id}/confirm-score")
def confirm_score(challenge_id: int, user_id: int, is_agreed: bool, db: Session = Depends(get_db)):
    challenge = db.query(models.Challenge).filter(models.Challenge.id == challenge_id).first()
    if not challenge:
        raise HTTPException(status_code=404, detail="Challenge not found")
        
    if is_agreed:
        challenge.status = "COMPLETED"
        # Tentukan Pemenang
        # Tentukan Pemenang dan Update ELO
        if challenge.challenger_score is not None and challenge.opponent_score is not None:
            challenger = db.query(models.User).filter(models.User.id == challenge.challenger_id).first()
            opponent = db.query(models.User).filter(models.User.id == challenge.opponent_id).first()
            
            if challenger and opponent:
                if challenge.challenger_score > challenge.opponent_score:
                    challenge.winner_id = challenge.challenger_id
                    score_a = 1
                elif challenge.opponent_score > challenge.challenger_score:
                    challenge.winner_id = challenge.opponent_id
                    score_a = 0
                else:
                    challenge.winner_id = None
                    score_a = 0.5

                new_c_elo, new_o_elo = calculate_elo(challenger.elo, opponent.elo, score_a)
                challenger.elo = max(0, new_c_elo)
                opponent.elo = max(0, new_o_elo)
    else:
        challenge.is_conflict = True
        challenge.status = "CONFLICT"
        
    db.commit()
    db.refresh(challenge)
    return {"message": "Konfirmasi berhasil", "challenge": challenge}

@app.post("/challenges/{challenge_id}/upload-proof")
def upload_proof(challenge_id: int, file: UploadFile = File(...), db: Session = Depends(get_db)):
    challenge = db.query(models.Challenge).filter(models.Challenge.id == challenge_id).first()
    if not challenge:
        raise HTTPException(status_code=404, detail="Challenge not found")
        
    upload_dir = "uploads/proofs"
    os.makedirs(upload_dir, exist_ok=True)
    file_path = f"{upload_dir}/{challenge_id}_{file.filename}"
    
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
        
    challenge.proof_image_url = file_path
    db.commit()
    
    # Mocking OCR
    ocr_text_mock = "Mock OCR detected score: 21 - 15"
    
    return {
        "message": "Bukti berhasil diunggah. OCR sedang memproses...", 
        "file_path": file_path,
        "ocr_result": ocr_text_mock,
        "instruction": "Admin/Sistem AI akan memvalidasi berdasarkan foto."
    }

# --- ENDPOINT TOURNAMENTS ---
@app.post("/tournaments/", response_model=schemas.Tournament)
def create_tournament(tournament: schemas.TournamentCreate, db: Session = Depends(get_db)):
    db_tournament = models.Tournament(**tournament.dict())
    db.add(db_tournament)
    db.commit()
    db.refresh(db_tournament)
    return db_tournament

@app.get("/tournaments/", response_model=List[schemas.Tournament])
def get_tournaments(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    return db.query(models.Tournament).offset(skip).limit(limit).all()

# --- ENDPOINT COMMUNITY (POSTS & COMMENTS) ---
@app.post("/posts/", response_model=schemas.Post)
def create_post(post: schemas.PostCreate, user_id: int, db: Session = Depends(get_db)):
    db_post = models.Post(**post.dict(), user_id=user_id)
    db.add(db_post)
    db.commit()
    db.refresh(db_post)
    return db_post

@app.get("/posts/", response_model=List[schemas.Post])
def get_posts(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    return db.query(models.Post).order_by(models.Post.created_at.desc()).offset(skip).limit(limit).all()

@app.post("/posts/{post_id}/comments/", response_model=schemas.Comment)
def create_comment(post_id: int, comment: schemas.CommentCreate, user_id: int, db: Session = Depends(get_db)):
    db_comment = models.Comment(**comment.dict(), post_id=post_id, user_id=user_id)
    db.add(db_comment)
    db.commit()
    db.refresh(db_comment)
    return db_comment

@app.get("/posts/{post_id}/comments/", response_model=List[schemas.Comment])
def get_comments(post_id: int, skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    return db.query(models.Comment).filter(models.Comment.post_id == post_id).offset(skip).limit(limit).all()

# --- ENDPOINT NOTIFICATIONS ---
@app.get("/notifications/{user_id}", response_model=List[schemas.Notification])
def get_notifications(user_id: int, db: Session = Depends(get_db)):
    return db.query(models.Notification).filter(models.Notification.user_id == user_id).order_by(models.Notification.created_at.desc()).all()

# --- ENDPOINT CHAT (WEBSOCKETS) ---
class ConnectionManager:
    def __init__(self):
        # Maps user_id to WebSocket connection
        self.active_connections: dict[int, WebSocket] = {}

    async def connect(self, websocket: WebSocket, user_id: int):
        await websocket.accept()
        self.active_connections[user_id] = websocket

    def disconnect(self, user_id: int):
        if user_id in self.active_connections:
            del self.active_connections[user_id]

    async def send_personal_message(self, message: dict, user_id: int):
        if user_id in self.active_connections:
            await self.active_connections[user_id].send_json(message)

manager = ConnectionManager()

def send_push_notification(expo_push_token: str, title: str, body: str, data: dict = None):
    try:
        response = requests.post(
            "https://exp.host/--/api/v2/push/send",
            json={
                "to": expo_push_token,
                "title": title,
                "body": body,
                "data": data or {},
                "sound": "default"
            },
            headers={
                "Accept": "application/json",
                "Content-Type": "application/json",
            }
        )
        return response.json()
    except Exception as e:
        print(f"Push notification failed: {e}")
        return None

@app.websocket("/ws/chat/{user_id}")
async def websocket_endpoint(websocket: WebSocket, user_id: int):
    await manager.connect(websocket, user_id)
    try:
        while True:
            data = await websocket.receive_json()
            # data harus mengandung receiver_id dan text
            receiver_id = data.get("receiver_id")
            text = data.get("text")
            
            if receiver_id and text:
                # 1. Simpan ke Database
                db = SessionLocal()
                new_msg = models.Message(
                    sender_id=user_id,
                    receiver_id=receiver_id,
                    text=text,
                    status="sent"
                )
                db.add(new_msg)
                db.commit()
                db.refresh(new_msg)
                
                msg_dict = {
                    "id": str(new_msg.id),
                    "sender_id": new_msg.sender_id,
                    "receiver_id": new_msg.receiver_id,
                    "text": new_msg.text,
                    "timestamp": new_msg.created_at.strftime("%H:%M"),
                    "status": new_msg.status
                }
                db.close()
                
                # 2. Kirim ke pengirim (sebagai konfirmasi)
                await manager.send_personal_message(msg_dict, user_id)
                
                # 3. Kirim ke penerima (jika online) atau kirim push notification jika offline
                if receiver_id in manager.active_connections:
                    await manager.send_personal_message(msg_dict, receiver_id)
                else:
                    db_session = SessionLocal()
                    receiver = db_session.query(models.User).filter(models.User.id == receiver_id).first()
                    sender = db_session.query(models.User).filter(models.User.id == user_id).first()
                    if receiver and receiver.expo_push_token and sender:
                        send_push_notification(
                            receiver.expo_push_token, 
                            f"Pesan dari {sender.full_name}", 
                            text,
                            {"type": "chat", "sender_id": user_id, "room_id": user_id}
                        )
                    db_session.close()
                
    except WebSocketDisconnect:
        manager.disconnect(user_id)
        
@app.get("/messages/{user_id}/{opponent_id}", response_model=List[schemas.Message])
def get_messages(user_id: int, opponent_id: int, db: Session = Depends(get_db)):
    messages = db.query(models.Message).filter(
        ((models.Message.sender_id == user_id) & (models.Message.receiver_id == opponent_id)) |
        ((models.Message.sender_id == opponent_id) & (models.Message.receiver_id == user_id))
    ).order_by(models.Message.created_at.asc()).all()
    return messages

# End of file

@app.put("/users/{user_id}/push-token")
def update_push_token(user_id: int, token_data: schemas.PushTokenUpdate, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    user.expo_push_token = token_data.expo_push_token
    db.commit()
    return {"message": "Push token updated successfully"}
