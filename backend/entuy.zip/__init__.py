# Init for backend module
